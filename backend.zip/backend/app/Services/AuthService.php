<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthService
{
    public function inscrireMedecin(array $donnees): User
    {
        return User::create([
            'nom' => $donnees['nom'],
            'email' => $donnees['email'],
            'password' => $donnees['password'],
            'role' => 'medecin',
        ]);
    }

    public function connecter(string $email, string $password): array
    {
        $user = User::where('email', $email)->first();

        if (! $user || ! Hash::check($password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['Email ou mot de passe incorrect.'],
            ]);
        }

        return [
            'user' => $user,
            'token' => $user->createToken('auth')->plainTextToken,
        ];
    }

    public function deconnecter(User $user): void
    {
        $user->currentAccessToken()->delete();
    }
}